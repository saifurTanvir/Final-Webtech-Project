-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2019 at 04:30 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(10) NOT NULL,
  `writerid` varchar(50) NOT NULL,
  `heading` varchar(50) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `keywords` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `writerid`, `heading`, `description`, `keywords`) VALUES
(4, '201', 'Binary Search', 'Binary search is an efficient algorithm for finding an item from a sorted list of items. It works by repeatedly dividing in half the portion of the list that could contain ', 'binary search|logn'),
(5, '202', 'Bangladesh', 'The etymology of Bangladesh (Country of Bengal) can be traced to the early 20th century, when Bengali patriotic songs, such as Namo Namo Namo Bangladesh Momo by Kazi Nazrul Islam and Aaji Bangladesher Hridoy by Rabindranath Tagore, used the term.[22] The term Bangladesh was often written as two words, Bangla Desh, in the past. Starting in the 1950s, Bengali nationalists used the term in political rallies in East Pakistan.  ', 'Bangladesh|libaration war'),
(6, '1001', 'USA', 'The earliest known use of the name \"America\" dates to April 25, 1507, when it was applied to the lands of the Western Hemisphere on a world map. The map was created and published by Martin Waldseemüller, a German cartographer in the town of Saint-Dié-des-Vosges, Lorraine, to honor the Italian explorer Amerigo Vespucci (Latin: Americus Vespucius).[', 'usa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
