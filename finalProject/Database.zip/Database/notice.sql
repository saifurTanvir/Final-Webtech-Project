-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2019 at 04:30 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(10) NOT NULL,
  `subject` varchar(70) NOT NULL,
  `title` varchar(70) NOT NULL,
  `description` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `subject`, `title`, `description`) VALUES
(1, 'English 1st Part[A]', 'Class cancel', 'Today class is canceled, please be informed.'),
(2, 'Admin', 'Urgent Meeting', 'Please attend todays meeting at 05:00 o clock.\r\nRegards\r\nMd. Saifur Rahman\r\nPrincipal '),
(4, 'Admin', 'Eid Bonus', 'Eid bonus will be added current months salary which will ready tomorrow.\r\nRegards\r\nAccounts Department'),
(5, 'Bangla 1st Part[B]', 'Class Cancel ', 'Today class is canceled for unavoidable reason.'),
(6, 'Bangla 1st Part[B]', 'Project Defense ', 'Dear Students, Project defense venue is CL-16. Thank you.'),
(7, 'Bangla 1st Part[A]', 'Lab Final', 'Date: 12/12/2019 (Thursday) Room: CL-15 Time: 9am-12pm'),
(8, 'Bangla 1st Part[A]', 'Group Info', 'Dear Students, Please carefully fill up the following google form (any one group member) by tomorrow. https://forms.gle/4WGPG3avaYsT3zJW9 Thank you.'),
(9, 'Bangla 2nd Part[B]', 'Makeup quiz', 'Date: 17-10-2019 (tomorrow) Room: 1115 Time: 8-10 am '),
(10, 'Bangla 2nd Part[B]', 'Makeup Class', 'Please be informed about the make up class of the following date Date: 12/12/19 Time: 1:30-3:00 PM Room # 2111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
